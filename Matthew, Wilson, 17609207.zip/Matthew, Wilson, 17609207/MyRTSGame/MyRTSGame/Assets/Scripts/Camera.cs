﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera : MonoBehaviour {

	public float panSpeed = 20f;
	public float panBorderThickness = 10f;
	public Vector2 panLimit;

	public float scrollSpeed = 20f;
	public float minY = 20f;
	public float maxY = 120f;
	

	void Update () {
		
		Vector3 pos = transform.position;

		if (Input.GetKey("w") || Input.mousePosition.y >= Screen.height - panBorderThickness)
		{
			pos.z += panSpeed * Time.deltaTime;
		}
		if (Input.GetKey("s") || Input.mousePosition.y <=  panBorderThickness)
		{
			pos.z -= panSpeed * Time.deltaTime;
		}
		if (Input.GetKey("d") || Input.mousePosition.y >= Screen.width - panBorderThickness)
		{
			pos.x += panSpeed * Time.deltaTime;
		}
		if (Input.GetKey("a") || Input.mousePosition.y <= panBorderThickness)
		{
			pos.x -= panSpeed * Time.deltaTime;
		}
		
		float scroll = Input.GetAxis("Mouse Scrollwheel");
		pos.y -= scroll * scrollSpeed * 100f * Time.deltaTime;
	
		pos.x = Mathf.Clamp(pos.x, -panLimit.x, panlimit.x);
		pos.z = Mathf.Clamp(pos.z, -panLimit.y, panlimit.y);

		transform.position = pos;

	}
}
