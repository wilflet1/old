﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyRTSGame
{
    class Map
    {
       // for (int i = 0; i< 20; i++){
          //  for(int j = 1; j< 21, j++){
           //    lblMap.Text += ".";
    }
}

